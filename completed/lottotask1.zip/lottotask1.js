var clickInit = function(){
  $( "button" ).on( "click", function(){
    alert("this is now working on click");
  });
}

//initialise the functions
clickInit();
