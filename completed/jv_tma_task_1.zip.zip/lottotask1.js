var clickInit = function(){
    alert("this is now working");
}

//initialise the functions
clickInit();
